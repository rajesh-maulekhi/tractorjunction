<style>
    .paa9 {
        text-align: left;
        line-height: 20px;
        text-align: justify;
        line-height: 1.7;
        padding: 36px;
    }
</style>
<body>
<?php
$root = "http://" . $_SERVER['HTTP_HOST'];
$root .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);
?>
<div class="banner" style="background:rgba(204, 0, 1, 0.7) none repeat scroll 0% 0%;height:105px;">
    <div class="container">
        <div class="col-sm-12 col-md-12" style="padding:15px 0px;">
            <ul type="none" style="color:#fff">
                <li style="float:left;padding-right:5px;"><i class="fa fa-home"
                                                             style="font-size:16px;padding-right:5px;"></i><a
                            style="color:white;" href="<?php echo $root; ?>">Home</a></li>
                <li style="float:left;padding-right:5px;">/</li>
                <li style="float:left;padding-right:5px;">Careers</li>
            </ul>
        </div>
    </div>
</div>
<div class="container" style="color:black;padding: 0px 15px;margin-top:-55px;background:transparent;">
    <div class="col-sm-12 col-md-12 paddingZ" style="padding-bottom: 90px;">
        <div class="col-sm-12 col-md-12 padding_0_in_small">
            <div class="box-wrapper">
                <div class="box1" style="padding: 30px 50px;">
                    <div class="row">
                        <h2 style="margin:10px 0px 0px;color:#148f1a;" class="font-upcoming">Careers at Tractor
                            Junction</h2>
                        <div class="border">
                            <div class="border-inner"></div>
                        </div>
                        <div class="col-md-12 prod-div" style="margin-bottom:20px;">
                            <div class="col-sm-12 col-md-12 padding_0_in_small">
                                <div class="col-sm-12 col-md-12 padding_0_in_small">
                                    <div class="col-md-12 paa9">
                                        <p style="font-family:inherit;">
                                            Be Part of Something Amazing
                                            We’re true believers in the power of the web and how it connects people to
                                            content. You want to use your talents for something big. You want the chance
                                            to make a difference, everyday. You want to be part of something that
                                            everyone’s talking about. And you wouldn’t mind having lots of fun along the
                                            way with people as driven and excited as you.
                                            Send your resume at:-
                                        </p>
                                        <p style="text-align:right;font-weight:600;color:#DB4C4C">
                                            <i class="fa fa-map-marker" style="color:#148F1A"></i><span
                                                    style="color:#148F1A">
										Address:</span><span> <br>Plot No. 44,  Ground floor,  Azad <br>Nagar, Alwar,  Rajasthan- 301001</span><br>
                                            <i class="fa fa-envelope" style="color:#148F1A"></i><span
                                                    style="color:#148F1A"> Mail: </span><span>tractorjunction@gmail.com</span><br>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>