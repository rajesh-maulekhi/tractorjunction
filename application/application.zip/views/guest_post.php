<style>
    .paa9 {
        text-align: left;
        line-height: 20px;
        text-align: justify;
        line-height: 1.7;
        padding: 36px;
    }
	@media only screen and (min-width:320px) and (max-width:768px) {
		.font-upcoming{    padding-left: 24px;    margin-bottom: 20px !important;
    text-align: center;}
		.border {display:none;}
			
.prod-div {    text-align: center !important;
margin: auto !important;width: 87%;    margin-bottom: 10px !important;
}
.MaonCC{padding: 6px;}
	}
</style>
<body>
<?php
$root = "http://" . $_SERVER['HTTP_HOST'];
$root .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);
?>
<div class="banner" style="background:rgba(204, 0, 1, 0.7) none repeat scroll 0% 0%;height:105px;">
    <div class="container">
        <div class="col-sm-12 col-md-12" style="padding:15px 0px;">
            <ul type="none" style="color:#fff">
                <li style="float:left;padding-right:5px;"><i class="fa fa-home"
                                                             style="font-size:16px;padding-right:5px;"></i><a
                            style="color:white;" href="<?php echo $root; ?>">Home`</li>
                <li style="float:left;padding-right:5px;">/</li>
                <li style="float:left;padding-right:5px;">Submit Guest Post </li>
            </ul>
        </div>
    </div>
</div>
<div class="container" style="color:black;padding: 0px 15px;margin-top:-55px;background:transparent;">
    <div class="col-sm-12 col-md-12 paddingZ" style="padding-bottom: 90px;">
        <div class="col-sm-12 col-md-12 padding_0_in_small ">
            <div class="box-wrapper">
                <div class="box1" style="padding: 30px 50px;">
                    <div class="row">
                        <h3 style="margin:10px 0px 0px;color:#148f1a;    font-size: 24px;" class="font-upcoming">Submit Guest Post </h3>
                        <div class="border" style="margin-top: 10px;">
                            <div class="border-inner"></div>
                        </div>
                        <div class="col-md-12 prod-div" style="margin-bottom:20px;">
                            <div class="col-sm-12 col-md-12 padding_0_in_small">
                                <div class="col-sm-12 col-md-12 padding_0_in_small">
                                    <div class="col-md-12 paa9" style="    padding-top: 20px;
    padding-bottom: 20px;
    text-align: justify;">
                                        <p style="font-family:inherit;" class="MaonCC">
We are right now accepting the fantastic article forTractor Junction, an online production where you can distribute your own scholarly people. In the event that you are a specialized essayist, magazine distributer or columnist, you can present your article on our site.
<br>
<br>
On the off chance that you are keen on being a general supporter, we will distribute a short "Writer Bio" area toward the finish of your article, where you can present yourself as the writer of the article. You can add connections to your site, Facebook profile, Google+ profile, Twitter profile and LinkedIn profile in your "Writer Bio" area.
<br>
<br>
<b>Note:</b>
<br>
<ul>
<li>	Unique profile picture</li>
<li>	"Creator Bio" ought to contain 15 to 40 words</li>
</ul>
<br>
 
We cherish and trust all sort of instructive article that can help our peruses. If you don't mind compose the article that is exclusively centered on quality and identified with our site. Else, we aren't ready to distribute the article. Before begin composing the article, please check our past article, classifications, and catchphrases to compose an appropriate article that can without much of a stretch endorse.
<br>
<br>
<b>Visitor Post Submission Guidelines</b>
<br>
Before presenting the article and getting affirmed, please take after the rules:
<br>
<br>
"Article" ought to be 100% one of a kind and new. It ought to breeze through the CopyScape Premium test.
<br>
<br>
"Article Title" ought to be 40 to 70 characters with proper significance.
<br>
<br>
"Article Body" ought to contain no less than 600 words (Six hundred words). We are just tolerating an article with 600 to 2000 words.

<br>
<br>
We favor at least one outside connections inside the "Article Body". In any case, our arbitrators will audit every one of the connections and on the off chance that they find appropriate, then they will distribute.

<br>
<br>
If it's not too much trouble be reminded every one of the connections will have nofollow tag. In any case, on the off chance that you wish that your connection will have a dofollow label, we request a negligible installment relying upon your financial plan.

<br>
<br>
Cool pictures identified with the article is profoundly prescribed. We acknowledge just eminence free pictures with the best possible picture credit.


<br>
<br>
Once your article is distributed to our site, you can't have the capacity to re-distribute to anyplace.

<br>
<br>
Once your article is prepared according to our rules please send the article to <b>editortractorjunction@gmail.com</b>. If you don't mind ensure your email ought to contain "Article Title", "Article Body", "Pictures for the Article with picture source", "Watchword Suggestion", "Writer Name", "Writer's Profile Image","Short Author Bio", "Writer's Website URL" and "Connection of your online networking profile".
<br>
<br>
In the event that you require some other data or rules don't hesitate to get in touch with us whenever. If you don't mind email us to editortractorjunction@gmail.com or visit the Contact Us page.

 


                                        </p>
                                 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
