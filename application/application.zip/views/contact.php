<style>
    .paa9 {
        text-align: left;
        line-height: 20px;
        text-align: justify;
        line-height: 1.7;
        padding: 36px;
    }
</style>
<body>
<?php
$root = "http://" . $_SERVER['HTTP_HOST'];
$root .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);
?>
<div class="banner" style="background:rgba(204, 0, 1, 0.7) none repeat scroll 0% 0%;height:105px;">
    <div class="container">
        <div class="col-sm-12 col-md-12" style="padding:15px 0px;">
            <ul type="none" style="color:#fff">
                <li style="float:left;padding-right:5px;"><i class="fa fa-home"
                                                             style="font-size:16px;padding-right:5px;"></i><a
                            style="color:white" href="<?php echo $root ?>">Home</a></li>
                <li style="float:left;padding-right:5px;">/</li>
                <li style="float:left;padding-right:5px;">Cntact Us</li>
            </ul>
        </div>
    </div>
</div>
<div class="container" style="padding: 0px 15px;margin-top:-55px;background:transparent;">
    <div class="col-sm-12 col-md-12 paddingZ" style="padding-bottom: 90px;">
        <div class="col-sm-12 col-md-12 padding_0_in_small">
            <div class="box-wrapper">
                <div class="box1" style="padding: 30px 50px;">
                    <div class="row">
                        <h2 style="margin:10px 0px 0px;color:#148f1a;" class="font-upcoming">Contact<span
                                    style="color:#cc0001;">   Us</span></h2>
                        <div class="border">
                            <div class="border-inner"></div>
                        </div>
                        <div class="col-md-12 padd0">
                            <div class="col-sm-6 col-md-4 info" style="border-right:2px solid #eee;">
                                <section class="heading-bordered">
                                </section>
                                <address style="margin-bottom:0px;">
                                    <ul class="list-unstyled" style="color:black">
                                        <li><span class="address"><i class="fa fa-home"
                                                                     style="color:#DB4C4C;font-size:20px;">&nbsp;</i><span
                                                        style="font-size: 20px;color:#DB4C4C;">Address:</span><br> Tractor Junction</span>
                                            <p class="address-content">
                                                44, First Floor<br>Azad Nagar Ward No 43 ,<br> Alwar (Raj.)-301001</p>
                                        </li>
                                        <li><i class="fa fa-phone" style="color:#DB4C4C;font-size:20px;"></i>&nbsp;&nbsp;<span
                                                    style="font-size: 20px;color:#DB4C4C;">Call Us</span>
                                            <br>
                                            <p style="color: #353535;"> 9414057796</p></li>
                                        <li><i class="fa fa-envelope" style="color:#DB4C4C;font-size:20px;"></i>&nbsp;&nbsp;<span
                                                    style="font-size: 20px;color:#DB4C4C;">Email:</span>
                                            <br>
                                            <p style="color: #353535;">tractorjunction@gmail.com</p></li>
                                    </ul>
                                </address>
                                <div class="col-sm-12 col-md-12 paddingZ text-center" style="margin-bottom:10px;">
                                    <div class="itemmF">
                                        <a href="https://www.facebook.com/tractorjunction/" class="linkmF"
                                           target="_blank">
                                            <i class="fa fa-facebook"
                                               style="padding: 9px 12px;font-size:14px;color:#fff;"></i>
                                        </a>
                                    </div>
                                    <div class="itemmT">
                                        <a href="https://twitter.com/tractorjunction" class="linkmT" target="_blank"
                                           style="top:-3px;">
                                            <i class="fa fa-twitter"
                                               style="padding: 9px 12px;font-size:14px;color:#fff;"></i>
                                        </a>
                                    </div>
                                    <div class="itemmG">
                                        <a href="https://plus.google.com/u/0/111375983648287404977?hl=en" class="linkmG"
                                           target="_blank">
                                            <i class="fa fa-google-plus"
                                               style="padding: 9px 12px;font-size:14px;color:#fff;"></i>
                                        </a>
                                    </div>
                                    <div class="itemmG">
                                        <a href="https://www.instagram.com/tractor_junction/" class="linkmG"
                                           target="_blank">
                                            <i class="fa fa-instagram"
                                               style="background:rgb(0,72,121) !important;padding: 9px 12px;font-size:14px;color:#fff;"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-8 padding_0_in_small">
                                <div class="titleline-footer"></div>
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d113192.11226413392!2d76.64637575!3d27.55464175!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3972998fa7e65df3%3A0x38cebba39ee426f2!2sAlwar%2C+Rajasthan!5e0!3m2!1sen!2sin!4v1436254059154"
                                        width="100%" height="250" frameborder="0" style="border:0"
                                        allowfullscreen></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
