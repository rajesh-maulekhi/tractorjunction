<style>
    .paa9 {
        text-align: left;
        line-height: 20px;
        text-align: justify;
        line-height: 1.7;
        padding: 36px;
    }
</style>
<body>
<?php
$root = "http://" . $_SERVER['HTTP_HOST'];
$root .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);
?>
<div class="banner" style="background:rgba(204, 0, 1, 0.7) none repeat scroll 0% 0%;height:105px;">
    <div class="container">
        <div class="col-sm-12 col-md-12" style="padding:15px 0px;">
            <ul type="none" style="color:#fff">
                <li style="float:left;padding-right:5px;"><i class="fa fa-home"
                                                             style="font-size:16px;padding-right:5px;"></i><a
                            style="color:white;" href="<?php echo $root; ?>">Home`</li>
                <li style="float:left;padding-right:5px;">/</li>
                <li style="float:left;padding-right:5px;">Advertise With Us</li>
            </ul>
        </div>
    </div>
</div>
<div class="container" style="color:black;padding: 0px 15px;margin-top:-55px;background:transparent;">
    <div class="col-sm-12 col-md-12 paddingZ" style="padding-bottom: 90px;">
        <div class="col-sm-12 col-md-12 padding_0_in_small ">
            <div class="box-wrapper">
                <div class="box1" style="padding: 30px 50px;">
                    <div class="row">
                        <h2 style="margin:10px 0px 0px;color:#148f1a;" class="font-upcoming">Advertise With Us</h2>
                        <div class="border">
                            <div class="border-inner"></div>
                        </div>
                        <div class="col-md-12 prod-div" style="margin-bottom:20px;">
                            <div class="col-sm-12 col-md-12 padding_0_in_small">
                                <div class="col-sm-12 col-md-12 padding_0_in_small">
                                    <div class="col-md-12 paa9">
                                        <p style="font-family:inherit;">
                                            Tractor Junction is the right platform to reach out to your customers. We
                                            ensure that your advertising messages reach the relevant customer in the
                                            right way.
                                            For any advertising options and corporate tie-ups, you may contact us at the
                                            below details:
                                        </p>
                                        <p style="text-align:right;font-weight:600;color:#DB4C4C">
                                            <i class="fa fa-user"></i> <span>Mr. Rajat Gupta</span><br>
                                            <i class="fa fa-phone"></i> <span>+91-9414057796</span><br>
                                            <i class="fa fa-envelope"></i>
                                            <span>tractorjunction@gmail.com</span><br>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
