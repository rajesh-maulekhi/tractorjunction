<?php

class Mobile_template extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');
        $this->load->helper('shweta');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library("pagination");
		    $this->load->model("form_model");
		    $this->load->model("Front_model");
    }

    function index()
    {
  
        // $this->load->view('header');
        $this->load->view('mobile_home_page');
        // $this->load->view('footer');

    }
function SingleBlog($slug){
	
	$totalCount=0;
		$totalCount = $this->Front_model->getBBlogTotalCount('slug',$slug);
		$totalCount=$totalCount+1;
		$this->Front_model->updateBlogViewCount($data=array('total_view'=>$totalCount),'slug',$slug);
		

	$result['totalCount']=$totalCount;
	$cond="slug='".$slug."'";
	  $result['result'] = shweta_select_th('*', 'blog', $cond);
	    
	    $seo_tags=$result['result'][0]->seo_tags;
		$meta_tag=unserialize(base64_decode($seo_tags));
	
	   $meta = array(
            'meta_title' => $meta_tag['meta_title'],
            'meta_keywords' => $meta_tag['meta_keyword'],
            'meta_description' => $meta_tag['meta_description'],
            'meta_robots' => 'all',
            'extra_headers' => ''

        );
	 
        $data = array();
        $data = array_merge($data, $meta); 
       $result['popular_result'] = $this->form_model->show_blog(4, 0);
        $this->load->view('header', $data);
        $this->load->view('single_blog',$result);
        $this->load->view('footer');
	}
}

?>